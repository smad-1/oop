#include "person.h"

#include <iostream>

using namespace std;

person:: person()
{
    name="";
    phone=-1;
    age=-1;
}

person:: ~person()
{

}


