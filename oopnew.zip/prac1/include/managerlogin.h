#ifndef MANAGERLOGIN_H_INCLUDED
#define MANAGERLOGIN_H_INCLUDED

#include <iostream>
#include <fstream>
#include <string>
#include <chrono>
#include <thread>
#include "myGlobals.h"

using namespace std;

void managerLogin(string user)
{
    using namespace std::this_thread;     // sleep_for, sleep_until
    using namespace std::chrono_literals; // ns, us, ms, s, h, etc.
    using std::chrono::system_clock;

    cout<<"\t\t\t________________________________\n\n";
    cout<<"\t\t\t   Logged in as manager.     \n\n\n";
    cout<<"\t\t\t________________________________\n\n";

    int choice=0;

    cout<<"\t\t\t1. Show user information."<<endl;
    cout<<"\t\t\t2. Show employee information."<<endl;
    cout<<"\t\t\tEnter choice: ";
    cin>>choice;

    system("cls");

    if(choice==1)
    {
        ///showUser()

        globals::emps[globals::emp_count - 1]->showUser();

        getchar();
        managerLogin(user);

        /*
        string s= user + ".txt";
        ifstream read(s);

        string username,name,shift;
        int age, phone, id, sal;

        read>>username>>name>>age>>phone>>id>>shift>>sal;

        cout<<"Name: "<<name<<endl;
        cout<<"Age: "<<age<<endl;
        cout<<"Phone: "<<phone<<endl;
        cout<<"ID: "<<<id<<endl;
        cout<<"Shift: "<<shift<<endl;
        cout<<"Salary: "<<sal<<endl;
        */


    }
    else if(choice==2)
    {
        ///showempinfo

        for(int i=0; i<globals::emp_count; i++)
        {
            cout<<"Employee "<<i+1<<":"<<endl;
            globals::emps[i]->showUser();
            cout<<endl<<endl;
        }
    }
    else
    {
        cout<<"Invalid choice. Please try again."<<endl;
        sleep_for(2s);
        system("cls");
        managerLogin(user);
    }
}

#endif // MANAGERLOGIN_H_INCLUDED
