#ifndef MYGLOBALS_H_INCLUDED
#define MYGLOBALS_H_INCLUDED

#include "employee.h"

#pragma once

namespace globals{

  extern employee* emps[100];
  extern int emp_count;

}

#endif // MYGLOBALS_H_INCLUDED
