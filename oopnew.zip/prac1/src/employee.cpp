#include "employee.h"
#include <fstream>
#include <iostream>
//#include "person.cpp"
//#include "person.h"

using namespace std;

int employee::ID=0;

employee::employee(string user, string pass): person()
{
    ID=++ID;
    username=user;
    shift="NULL";
    password=pass;
    salary=0;
}

employee::~employee()
{

}
void employee::setInfo()
{
    string s= username + ".txt";
    ofstream fp(s,ios::app);

    cout<<"Name: ";
    cin>>name;
    fp<<name<<endl;

    getchar();
    cout<<"Age: ";
    cin>>age;
    fp<<age<<endl;

    getchar();
    cout<<"Phone number: ";
    cin>>phone;
    fp<<phone<<endl;

    getchar();
    cout<<"Employee ID: "<<ID<<endl;
    fp<<ID<<endl;

    cout<<"Shift: ";
    cin>>shift;
    fp<<shift<<endl;

    getchar();
    cout<<"Salary: ";
    cin>>salary;
    fp<<salary<<endl;

    fp.close();
}

void employee::getInfo()
{
    cout<<"Name: "<<name<<endl;
    cout<<"Age: "<<age<<endl;
    cout<<"Phone number: "<<phone<<endl;
    cout<<"Employee ID: "<<ID<<endl;
    cout<<"Shift: "<<shift<<endl;
    cout<<"Salary: "<<salary<<endl;
}
