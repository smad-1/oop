#include "manager.h"
#include "myGlobals.h"
//#include "signup.h"

manager::manager(string user, string pass):employee(user,pass)
{
    //ctor
}

manager::manager(string user, string pass, string n, int a, int p, string shif,int sal):employee(user,pass)
{
    name=n;
    age=a;
    phone=p;
    shift=shif;
    salary=sal;
}

manager::~manager()
{
    //dtor
}

void manager::showUser()
{
    getInfo();
}

void manager::showEmpInfo()
{
    for(int i=0; i<globals::emp_count; i++)
    {
        globals::emps[i]->getInfo();
    }
}
