#include <iostream>
#include <string>
#include <chrono>
#include <thread>
#include <fstream>
#include "person.h"
#include "signup.h"
#include "myGlobals.h"
#include "managerlogin.h"

namespace globals{

  employee* emps[100];
  int emp_count=0;
}

//employee* emps[100];

using namespace std;

int main(void)
{
   // person p("Sad",22,123);
  //  p.getInfo();

  using namespace std::this_thread;     // sleep_for, sleep_until
  using namespace std::chrono_literals; // ns, us, ms, s, h, etc.
  using std::chrono::system_clock;

    ///update value of emp_count every time program is ran

    ifstream countuser("records.txt"); //read
    string lines;
    globals::emp_count=0;
    if(countuser.is_open())
    {
        while(countuser.peek()!=EOF)
        {
            getline(countuser,lines);
            globals::emp_count++;
        }
        countuser.close();
    }

    ///update emps[] every time program is ran   //read, e_emp,

    if(globals::emp_count != 0)
    {
        ifstream read("records.txt");
        string empvar,emppass;
        for(int i=0; i<globals::emp_count; i++)
        {
            read>>empvar>>emppass;
            string ss= empvar + ".txt";

            ifstream r_emp(ss);
            string us,name,shift;
            int age,phone,id,sal;

            r_emp>>us>>name>>age>>phone>>id>>shift>>sal;  //empvar=us

            string check;
            ifstream cman("manager.txt");
            while(cman>>check)
            {
                if(check==us)
                {
                    globals::emps[i] = new manager(empvar,emppass,name,age,phone,shift,sal);
                }
            }
            cman.close();

            ifstream cchef("chef.txt");
            while(cchef>>check)
            {
                if(check==us)
                {
                   // globals::emps[i] = new chef(empvar,emppass,name,age,phone,shift,sal);
                }
            }
            cchef.close();

            ifstream ccash("cashier.txt");
            while(ccash>>check)
            {
                if(check==us)
                {
                  //  globals::emps[i] = new cashier(empvar,emppass,name,age,phone,shift,sal);
                }
            }
            ccash.close();

            ifstream cser("server.txt");
            while(cser>>check)
            {
                if(check==us)
                {
                  //  globals::emps[i] = new server(empvar,emppass,name,age,phone,shift,sal);
                }
            }
            cser.close();
            r_emp.close();
        }
        read.close();
    }

  int choice;
  cout<<"\t\t\t________________________________\n\n";
  cout<<"\t\t\t   WELCOME TO THE LOGIN PAGE     \n\n\n";
  cout<<"\t\t\t1. Login."<<endl;
  cout<<"\t\t\t2. Sign up."<<endl;
  cout<<"\t\t\t3. Forgot password."<<endl;
  cout<<"\t\t\t4. Exit.\n"<<endl;
  cout<<"\t\t\tEnter choice: ";
  cin>>choice;
  cout<<endl;

  system("cls");

  int option; // for logging in
  string userID, userPass;

  switch(choice)
  {
  case 1:
    {
        sleep_for(1s);
        cout<<"\t\t\t1. Login as Manager."<<endl;
        cout<<"\t\t\t2. Login as Chef."<<endl;
        cout<<"\t\t\t3. Login as Cashier."<<endl;
        cout<<"\t\t\t4. Login as Server."<<endl;

        cin>>option;

        system("cls");

        cout<<"\t\t\t LOGIN PAGE   \n\n";
        cout<<"\t\t\tEnter username: ";
        cin>>userID;
        cout<<"\t\t\tEnter password: ";
        cin>>userPass;

        bool log=login(option,userID,userPass);

        if(log) break;
        else main();
    }
  case 2:
    {
        sleep_for(1s);
        string title;
        cout<<"Job title (manager/chef/cashier/server): ";
        cin>>title;
        register_(title);
        main();
        break;
    }
  case 3:
    {
        cout<<"forgot pass"<<endl;
        break;
    }
  case 4:
    {
        cout<<"\t\t\tExiting home page. Thank You!\n\n";
        break;
    }
  default:
    {
       // system("cls");
        cout<<"\t\t\tInvalid choice.\n\n";
        sleep_for(2s);
        system("cls");
        main();
    }
  }

  if(option==1)  // manager log in
  {
    managerLogin(userID);

   // cout<<globals::emp_count<<endl;

   // globals::emps[0]->setInfo();
   // globals::emps[globals::emp_count-1]->showUser();
  }




    return 0;
} // namespace std;
