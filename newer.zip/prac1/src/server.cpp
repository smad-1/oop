#include "server.h"
#include "myGlobals.h"

server::server(string user, string pass,int i):employee(user,pass,i)
{
    //ctor
}

server::server(string user, string pass, string n, int a, long long int p, int i, string shif,int sal):employee(user,pass,i)
{
    name=n;
    age=a;
    phone=p;
    shift=shif;
    salary=sal;
}

server::~server()
{
    //dtor
}

void server::showUser()
{
    getInfo();
}

