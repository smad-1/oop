#ifndef CASHIERLOGIN_H_INCLUDED
#define CASHIERLOGIN_H_INCLUDED

#include <iostream>
#include <fstream>
#include <string>
#include <chrono>
#include <thread>
#include "myGlobals.h"
#include "menu.h"

using namespace std;

void cashierLogin(string user)
{
    using namespace std::this_thread;     // sleep_for, sleep_until
    using namespace std::chrono_literals; // ns, us, ms, s, h, etc.
    using std::chrono::system_clock;

    int choice=0;

    cout<<"\t\t\t1. Show user information."<<endl;
    cout<<"\t\t\t2. See shift."<<endl;
    cout<<"\t\t\t3. See salary."<<endl;
    cout<<"\t\t\t4. See menu."<<endl;
    cout<<"\t\t\t5. Log out."<<endl<<endl;
    cout<<"\t\t\tEnter choice: ";
    cin>>choice;

    system("cls");

    if(choice==1)  ///showUser()
    {
        string s= user + ".txt";
        ifstream ifs(s);  //read

        string u, n, shif; //user, name, shift
        int age, id, sal;
        long long int phone;

        ifs>>u>>n>>age>>phone>>id>>shif>>sal;

        int idx=id-1;

        globals::emps[idx]->showUser();

        getchar();
        getchar();
        system("cls");
        cashierLogin(user);

    }
    else if(choice==2)  /// see shift
    {
        string s= user + ".txt";
        ifstream ifs(s);

        string u, n, shif; //user, name, shift
        int age, id, sal;
        long long int phone;

        ifs>>u>>n>>age>>phone>>id>>shif>>sal;

        int idx=id-1;

        globals::emps[idx]->getShift();

        getchar();
        getchar();
        system("cls");
        cashierLogin(user);
    }
    else if(choice==3) ///see salary
    {
        string s= user + ".txt";
        ifstream ifs(s);

        string u, n, shif; //user, name, shift
        int age, id, sal;
        long long int phone;

        ifs>>u>>n>>age>>phone>>id>>shif>>sal;

        int idx=id-1;

        globals::emps[idx]->getSal();

        getchar();
        getchar();
        system("cls");
        cashierLogin(user);
    }
    else if(choice==4)  ///see menu
    {
        showMenu();
        getchar();
        getchar();
        system("cls");
    }
    else if(choice==5)  ///log out
    {
        cout<<"\t\t\tLogging out."<<endl;
        sleep_for(2s);
        system("cls");
        return;
    }
    else
    {
        cout<<"\t\t\tInvalid choice. Please try again."<<endl;
        sleep_for(1s);
        system("cls");
        cashierLogin(user);
    }
}

#endif // CASHIERLOGIN_H_INCLUDED
