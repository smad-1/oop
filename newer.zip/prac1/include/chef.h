#ifndef CHEF_H
#define CHEF_H

#include <employee.h>


class chef : public employee
{
    private:


    public:
        chef(string user, string pass,int i);
        chef(string user, string pass, string n, int a, long long int p,int i, string shif,int sal);
        virtual ~chef();
        void showUser();

        //menu
        //working hours + shift +salary
};

#endif // CHEF_H
