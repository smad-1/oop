#include <bits/stdc++.h>
#ifndef DESSERT_H
#define DESSERT_H

#include "courses.h"

using namespace std;

class dessert : public courses
{
public:
    dessert(int num, string n, float p):courses(num,n,p)
    {

    }

    void showCourse()
    {
        cout<<number<<".    "<<name<<"    TK "<<price<<endl;
    }

};

#endif
