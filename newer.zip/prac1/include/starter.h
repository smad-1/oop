#include <bits/stdc++.h>
#ifndef STARTER_H
#define STARTER_H

#include "courses.h"

using namespace std;

class starter:public courses
{
    public:
        starter(){}
        starter(int num, string n, float p): courses(num,n,p)
        {

        }

        void showCourse()
        {
            cout<<number<<".    "<<name<<"    TK "<<price<<endl;
        }


};

#endif
