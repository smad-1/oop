#include "manager.h"
#include "myGlobals.h"
//#include "signup.h"

manager::manager(string user, string pass,int i):employee(user,pass,i)
{
    //ctor
}

manager::manager(string user, string pass, string n, int a, long long int p, int i, string shif,int sal):employee(user,pass,i)
{
    name=n;
    age=a;
    phone=p;
    shift=shif;
    salary=sal;
    title="Manager";
}

manager::~manager()
{
    //dtor
}

void manager::showUser()
{
    getInfo();
}

void manager::showEmpInfo()
{
   for(int i=0; i<globals::emp_count; i++)
    {
        cout<<"Employee "<<i+1<<":"<<endl;
        globals::emps[i]->showUser();
        cout<<endl<<endl;
    }
}
