#include "supplier.h"

supplier::supplier(string n, long long int p, int a, int idx)
{
    supp_name=n;
    phone=p;
    age=a;
    supp_id=idx;
}

supplier::~supplier()
{
    //dtor
}
