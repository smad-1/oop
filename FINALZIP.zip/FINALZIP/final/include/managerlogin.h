#ifndef MANAGERLOGIN_H_INCLUDED
#define MANAGERLOGIN_H_INCLUDED

#include <bits/stdc++.h>
#include <iostream>
#include <fstream>
#include <string>
#include <chrono>
#include <thread>
#include <cstring>
#include "myGlobals.h"
#include "menu.h"

using namespace std;

void managerLogin(string user)
{
    using namespace std::this_thread;     // sleep_for, sleep_until
    using namespace std::chrono_literals; // ns, us, ms, s, h, etc.
    using std::chrono::system_clock;

    int choice=0;

    cout<<"\t\t\t________________________________\n\n";
    cout<<"\t\t\t   Logged in as MANAGER.     \n\n";
    cout<<"\t\t\t________________________________\n\n\n";

    cout<<"\t\t\t1. Show user information."<<endl;
    cout<<"\t\t\t2. Show employee information."<<endl;
    cout<<"\t\t\t3. Set employee shift."<<endl;
    cout<<"\t\t\t4. Set employee salary."<<endl;
    cout<<"\t\t\t5. Show supplier information."<<endl;
    cout<<"\t\t\t6. See menu."<<endl;
    cout<<"\t\t\t7. Remove employee."<<endl;
    cout<<"\t\t\t8. Log out."<<endl<<endl;
    cout<<"\t\t\tEnter choice: ";
    cin>>choice;

    system("cls");

    if(choice==1)
    {
        ///showUser()

        string s= user + ".txt";
        ifstream ifs(s);

        string u, n, shif; //user, name, shift
        int age, id, sal;
        long long int phone;

        ifs>>u>>n>>age>>phone>>id>>shif>>sal;

        int idx=id-1;

        globals::emps[idx]->showUser();

        getchar();
        getchar();
        system("cls");
        managerLogin(user);

    }
    else if(choice==2)
    {
        ///showempinfo

        cout<< "Employee Count: "<<globals::emp_count<<endl<<endl;
        for(int i=0; i<globals::emp_count; i++)
        {
            cout<<"Employee "<<i+1<<":"<<endl;
            globals::emps[i]->showUser();
            cout<<endl<<endl;
        }
        getchar();
        getchar();
        system("cls");
        managerLogin(user);
    }
    else if(choice==3)
    {
        ///set shift

        int op;
        cout<<"\t\t\tSet shift for: "<<endl<<endl;
        cout<<"\t\t\t1. Cashier. "<<endl;
        cout<<"\t\t\t2. Chef. "<<endl;
        cout<<"\t\t\t3. Server. "<<endl<<endl;
        cout<<"\t\t\tEnter option: ";
        cin>>op;

        system("cls");

        if(op==1) //cashier
        {
            ifstream countuser("cashier.txt"); //read
            string lines;
            int cashcount=0;

            if(countuser.is_open())
            {
                while(countuser.peek()!=EOF)
                {
                    getline(countuser,lines);
                    cashcount++;
                }
                countuser.close();
            }

            cout<<"\t\t\tCashiers: "<<endl;

            string nam,pass;
            ifstream getuser("cashier.txt");  //read          getuser,individual
            for(int i=0; i<cashcount; i++)
            {
                getuser>>nam>>pass;
                string s= nam + ".txt";

                ifstream individual(s);   // file of individual employee, has all info

                string u, n, shif; //user, name, shift
                int age, id, sal;
                long long int phone;

                individual>>u>>n>>age>>phone>>id>>shif>>sal;

                cout<<"\t\t\tID: "<<id<<" Name: "<<n<<" Username:"<<u<<endl;

                individual.close();

            }
            getuser.close();

            cout<<endl;
            string check;
            cout<<"\t\t\tEnter username of cashier: ";
            cin>>check;
            check = check + ".txt";

            string u, n, shif; //user, name, shift
            int age, id, sal;
            long long int phone;

            ifstream newfile(check);
            newfile>>u>>n>>age>>phone>>id>>shif>>sal;
            newfile.close();

            string newshift;
            cout<<"\t\t\tEnter new shift for cashier: ";
            cin>>newshift;

            ofstream ofs(check, ios::out | ios::trunc);  //WRITE + TRUNCATE
            ofs<<u<<endl;
            ofs<<n<<endl;
            ofs<<age<<endl;
            ofs<<phone<<endl;
            ofs<<id<<endl;
            ofs<<newshift<<endl;
            ofs<<sal<<endl;

            ofs.close();

            globals::emps[id-1]= new cashier(nam,pass,n,age,phone,id,newshift,sal);

            system("cls");
            managerLogin(user);
        }
        else if(op==2) // CHEF
        {
            ifstream countuser("chef.txt"); //read
            string lines;
            int chefcount=0;

            if(countuser.is_open())
            {
                while(countuser.peek()!=EOF)
                {
                    getline(countuser,lines);
                    chefcount++;
                }
                countuser.close();
            }

            cout<<"\t\t\tChefs: "<<endl;

            string nam,pass;
            ifstream getuser("chef.txt");  //read          getuser,individual
            for(int i=0; i<chefcount; i++)
            {
                getuser>>nam>>pass;
                string s= nam + ".txt";

                ifstream individual(s);   // file of individual employee, has all info

                string u, n, shif; //user, name, shift
                int age, id, sal;
                long long int phone;

                individual>>u>>n>>age>>phone>>id>>shif>>sal;

                cout<<"\t\t\tID: "<<id<<" Name: "<<n<<" Username:"<<u<<endl;

                individual.close();

            }
            getuser.close();

            cout<<endl;
            string check;
            cout<<"\t\t\tEnter username of chef: ";
            cin>>check;
            check = check + ".txt";

            string u, n, shif; //user, name, shift
            int age, id, sal;
            long long int phone;

            ifstream newfile(check);
            newfile>>u>>n>>age>>phone>>id>>shif>>sal;
            newfile.close();

            string newshift;
            cout<<"\t\t\tEnter new shift for chef: ";
            cin>>newshift;

            ofstream ofs(check, ios::out | ios::trunc);  //WRITE + TRUNCATE
            ofs<<u<<endl;
            ofs<<n<<endl;
            ofs<<age<<endl;
            ofs<<phone<<endl;
            ofs<<id<<endl;
            ofs<<newshift<<endl;
            ofs<<sal<<endl;

            ofs.close();

            globals::emps[id-1]= new chef(nam,pass,n,age,phone,id,newshift,sal);

            system("cls");
            managerLogin(user);
        }
        else if(op==3) //SERVER
        {
            ifstream countuser("server.txt"); //read
            string lines;
            int servcount=0;

            if(countuser.is_open())
            {
                while(countuser.peek()!=EOF)
                {
                    getline(countuser,lines);
                    servcount++;
                }
                countuser.close();
            }

            cout<<"\t\t\tServers: "<<endl;

            string nam,pass;
            ifstream getuser("server.txt");  //read          getuser,individual
            for(int i=0; i<servcount; i++)
            {
                getuser>>nam>>pass;
                string s= nam + ".txt";

                ifstream individual(s);   // file of individual employee, has all info


                string u, n, shif; //user, name, shift
                int age, id, sal;
                long long int phone;

                individual>>u>>n>>age>>phone>>id>>shif>>sal;

                cout<<"\t\t\tID: "<<id<<" Name: "<<n<<" Username:"<<u<<endl;

                individual.close();

            }
            getuser.close();
            cout<<endl;

            string check;
            cout<<"\t\t\tEnter username of server: ";
            cin>>check;
            check = check + ".txt";

            string u, n, shif; //user, name, shift
            int age, id, sal;
            long long int phone;

            ifstream newfile(check);
            newfile>>u>>n>>age>>phone>>id>>shif>>sal;
            newfile.close();

            string newshift;
            cout<<"\t\t\tEnter new shift for server: ";
            cin>>newshift;

            ofstream ofs(check, ios::out | ios::trunc);  //WRITE + TRUNCATE
            ofs<<u<<endl;
            ofs<<n<<endl;
            ofs<<age<<endl;
            ofs<<phone<<endl;
            ofs<<id<<endl;
            ofs<<newshift<<endl;
            ofs<<sal<<endl;

            ofs.close();

            globals::emps[id-1]= new server(nam,pass,n,age,phone,id,newshift,sal);

            system("cls");
            managerLogin(user);
        }
        else
        {
            cout<<"\t\t\tInvalid choice. Please try again."<<endl;
            sleep_for(1s);
            system("cls");
            managerLogin(user);
        }
    }
    else if(choice==4)
    {
        ///set salary

        int op;
        cout<<"\t\t\tSet salary for: "<<endl<<endl;
        cout<<"\t\t\t1. Cashier. "<<endl;
        cout<<"\t\t\t2. Chef. "<<endl;
        cout<<"\t\t\t3. Server. "<<endl<<endl;
        cout<<"\t\t\tEnter option: ";
        cin>>op;

        system("cls");

        if(op==1) //cashier
        {
            ifstream countuser("cashier.txt"); //read
            string lines;
            int cashcount=0;

            if(countuser.is_open())
            {
                while(countuser.peek()!=EOF)
                {
                    getline(countuser,lines);
                    cashcount++;
                }
                countuser.close();
            }

            cout<<"\t\t\tCashiers: "<<endl;

            string nam,pass;
            ifstream getuser("cashier.txt");  //read          getuser,individual
            for(int i=0; i<cashcount; i++)
            {
                getuser>>nam>>pass;
                string s= nam + ".txt";

                ifstream individual(s);   // file of individual employee, has all info

                string u, n, shif; //user, name, shift
                int age, id, sal;
                long long int phone;

                individual>>u>>n>>age>>phone>>id>>shif>>sal;

                cout<<"\t\t\tID: "<<id<<"  Name: "<<n<<"  Username:"<<u<<endl;

                individual.close();

            }
            getuser.close();

            cout<<endl;

            string check;
            cout<<"\t\t\tEnter username of cashier: ";
            cin>>check;
            check = check + ".txt";

            string u, n, shif; //user, name, shift
            int age, id, sal;
            long long int phone;

            ifstream newfile(check);
            newfile>>u>>n>>age>>phone>>id>>shif>>sal;
            newfile.close();

            int newsalary;
            cout<<"\t\t\tEnter new salary for cashier: ";
            cin>>newsalary;

            ofstream ofs(check, ios::out | ios::trunc);  //WRITE + TRUNCATE
            ofs<<u<<endl;
            ofs<<n<<endl;
            ofs<<age<<endl;
            ofs<<phone<<endl;
            ofs<<id<<endl;
            ofs<<shif<<endl;
            ofs<<newsalary<<endl;

            ofs.close();

            globals::emps[id-1]= new cashier(nam,pass,n,age,phone,id,shif,newsalary);

            system("cls");
            managerLogin(user);
        }
        else if(op==2) // CHEF
        {
            ifstream countuser("chef.txt"); //read
            string lines;
            int chefcount=0;

            if(countuser.is_open())
            {
                while(countuser.peek()!=EOF)
                {
                    getline(countuser,lines);
                    chefcount++;
                }
                countuser.close();
            }

            cout<<"\t\t\tChefs: "<<endl;

            string nam,pass;
            ifstream getuser("chef.txt");  //read          getuser,individual
            for(int i=0; i<chefcount; i++)
            {
                getuser>>nam>>pass;
                string s= nam + ".txt";

                ifstream individual(s);   // file of individual employee, has all info

                string u, n, shif; //user, name, shift
                int age, id, sal;
                long long int phone;

                individual>>u>>n>>age>>phone>>id>>shif>>sal;

                cout<<"\t\t\tID: "<<id<<" Name: "<<n<<" Username:"<<u<<endl;

                individual.close();

            }
            getuser.close();

            cout<<endl;
            string check;
            cout<<"\t\t\tEnter username of chef: ";
            cin>>check;
            check = check + ".txt";

            string u, n, shif; //user, name, shift
            int age, id, sal;
            long long int phone;

            ifstream newfile(check);
            newfile>>u>>n>>age>>phone>>id>>shif>>sal;
            newfile.close();

            int newsalary;
            cout<<"\t\t\tEnter new salary for chef: ";
            cin>>newsalary;

            ofstream ofs(check, ios::out | ios::trunc);  //WRITE + TRUNCATE
            ofs<<u<<endl;
            ofs<<n<<endl;
            ofs<<age<<endl;
            ofs<<phone<<endl;
            ofs<<id<<endl;
            ofs<<shif<<endl;
            ofs<<newsalary<<endl;

            ofs.close();

            globals::emps[id-1]= new chef(nam,pass,n,age,phone,id,shif,newsalary);

            system("cls");
            managerLogin(user);
        }
        else if(op==3) //SERVER
        {
            ifstream countuser("server.txt"); //read
            string lines;
            int servcount=0;

            if(countuser.is_open())
            {
                while(countuser.peek()!=EOF)
                {
                    getline(countuser,lines);
                    servcount++;
                }
                countuser.close();
            }

            cout<<"\t\t\tServers: "<<endl;

            string nam,pass;
            ifstream getuser("server.txt");  //read          getuser,individual
            for(int i=0; i<servcount; i++)
            {
                getuser>>nam>>pass;
                string s= nam + ".txt";

                ifstream individual(s);   // file of individual employee, has all info


                string u, n, shif; //user, name, shift
                int age, id, sal;
                long long int phone;

                individual>>u>>n>>age>>phone>>id>>shif>>sal;

                cout<<"\t\t\tID: "<<id<<" Name: "<<n<<" Username:"<<u<<endl;

                individual.close();

            }
            getuser.close();

            cout<<endl;
            string check;
            cout<<"\t\t\tEnter username of server: ";
            cin>>check;
            check = check + ".txt";

            string u, n, shif; //user, name, shift
            int age, id, sal;
            long long int phone;

            ifstream newfile(check);
            newfile>>u>>n>>age>>phone>>id>>shif>>sal;
            newfile.close();

            int newsalary;
            cout<<"\t\t\tEnter new salary for server: ";
            cin>>newsalary;

            ofstream ofs(check, ios::out | ios::trunc);  //WRITE + TRUNCATE
            ofs<<u<<endl;
            ofs<<n<<endl;
            ofs<<age<<endl;
            ofs<<phone<<endl;
            ofs<<id<<endl;
            ofs<<shif<<endl;
            ofs<<newsalary<<endl;

            ofs.close();

            globals::emps[id-1]= new server(nam,pass,n,age,phone,id,shif,newsalary);

            system("cls");
            managerLogin(user);
        }
        else
        {
            cout<<"\t\t\tInvalid choice. Please try again."<<endl;
            sleep_for(2s);
            system("cls");
            managerLogin(user);
        }
    }
    else if(choice==5) //supplier info
    {
        cout<<"\t\t\tSupplier information: "<<endl<<endl;


        for(int i=0; i<9; i++)
        {
           // cout<<"Supplier "<<i+1<<": "<<endl;
            globals::prods[i]->getInfo();
            cout<<endl;
        }

        getchar();
        getchar();
        system("cls");
        managerLogin(user);
    }
    else if(choice==6) // see menu
    {
        showMenu();
        getchar();
        getchar();
        system("cls");
        managerLogin(user);
    }
    else if(choice==7) //remove employee
    {
        int opt;
        cout<<"\t\t\t1.Remove a Server."<<endl;
        cout<<"\t\t\t2.Remove a Cashier."<<endl;
        cout<<"\t\t\t3.Remove a Chef."<<endl;
        cout<<"\t\t\Enter option: ";
        cin>>opt;

        string fp;
        if(opt==1) fp="server.txt";
        else if(opt==2) fp="cashier.txt";
        else if(opt==3) fp="chef.txt";
        else
        {
            cout<<"\t\t\tInvalid choice."<<endl;
            sleep_for(1s);
            system("cls");
            managerLogin(user);
        }

        ifstream f2(fp);
        string lines;
        int counts=0;
        if(f2.is_open())
        {
            while(f2.peek()!=EOF)
            {
                getline(f2,lines);
                counts++;
            }
            f2.close();
        }

        ifstream fr("records.txt");
        int countrecord=0;
        if(fr.is_open())
        {
            while(fr.peek()!=EOF)
            {
                getline(fr,lines);
                countrecord++;
            }
            fr.close();
        }
        class hold
        {
        public:
            string username;
            string password;
            hold(string u, string p):username(u),password(p)
            {

            }
        };

        vector<hold>vec1;  //records
        ifstream fr2("records.txt");
        for(int i=0; i<countrecord; i++)
        {
            string us, ps;
            fr2>>us>>ps;
            vec1.push_back(hold(us,ps));
        }
        fr2.close();

        vector<hold>vec2;  //server
        string nam,pass,s;
        ifstream getuser(fp);  //read          getuser,individual
        for(int i=0; i<counts; i++)
        {
            getuser>>nam>>pass;
            s= nam + ".txt";
            ifstream individual(s);   // file of individual employee, has all info

            string u, n, shif; //user, name, shift
            int age, id, sal;
            long long int phone;

            individual>>u>>n>>age>>phone>>id>>shif>>sal;
            vec2.push_back(hold(u,pass));

            cout<<"\t\t\tID: "<<id<<" Name: "<<n<<" Username:"<<u<<endl;

            individual.close();
        }
        getuser.close();

        cout<<endl;
        string chec;
        cout<<"\t\t\tEnter username of employee: ";
        cin>>chec;
        //chec file has to be deleted, records file update and fp file update

        ofstream files1("records.txt",ios::out | ios::trunc);
        for(auto item:vec1)
        {
            if(item.username != chec) files1<<item.username<<" " <<item.password<<endl;
        }
        files1.close();

        ofstream files2(fp,ios::out | ios::trunc);
        for(auto item:vec2)
        {
            if(item.username != chec) files2<<item.username<<" " <<item.password<<endl;
        }
        files2.close();

        chec = chec + ".txt";
        string filename(chec);
        if(remove(filename.c_str()) != 0) cout<<"\t\t\tError deleting file."<<endl;
        else cout<<"\t\t\tFile successfully deleted."<<endl;

        getchar();
        getchar();
        system("cls");
        managerLogin(user);
    }
    else if(choice==8) //exit
    {
        cout<<"\t\t\tLogging out."<<endl;
        sleep_for(2s);
        system("cls");
        return;
    }
    else
    {
        cout<<"\t\t\tInvalid choice. Please try again."<<endl;
        sleep_for(2s);
        system("cls");
        managerLogin(user);
    }
}

#endif // MANAGERLOGIN_H_INCLUDED
