#ifndef EMPLOYEE_H
#define EMPLOYEE_H
#include <iostream>

#include "person.h"

#pragma once

using namespace std;

class employee:public person
{
    protected:
        int ID;
        string username;
        string shift;
        string password;
        double salary;
        string title;

    public:
        employee(string user, string pass, int i);
        ~employee();
        void setInfo();
        void getInfo();
        void getSal();
        void getShift();
        virtual void showInfo();
        virtual void showUser()=0;

};

#endif
