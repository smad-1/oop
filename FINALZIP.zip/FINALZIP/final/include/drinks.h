#include <bits/stdc++.h>
#ifndef DRINKS_H
#define DRINKS_H

#include "courses.h"

using namespace std;

class drinks : public courses
{
    public:
       drinks(int num, string n, float p): courses(num,n,p)
       {

       }

       void showCourse()
       {
           cout<<number<<".    "<<name<<"    TK "<<price<<endl;
       }

};

#endif
