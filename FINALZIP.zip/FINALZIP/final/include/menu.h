#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED
#include <iostream>
#include "myGlobals.h"  //redefined courses class
#include "starter.h"
#include "maincourse.h"
#include "dessert.h"
#include "drinks.h"

void createMenu()
{
    globals::items[0]= new starter(1,"Fries(Small)", 50.0);
    globals::items[1]= new starter(2,"Fries(Large)", 75.0);
    globals::items[2]= new starter(3,"Dumplings", 175.0);
    globals::items[3]= new starter(4,"Spring-Rolls", 65.0);
    globals::items[4]= new starter(5,"Garlic-Bread", 260.0);
    globals::items[5]= new starter(6,"Nachos", 220.0);
    globals::items[6]= new starter(7,"Cashew-Nut-Salad", 260.0);

    globals::startNum=7;

    ofstream f1("starter.txt",ios::app);

    for(int i=0; i<7; i++)
    {
        f1<<globals::items[i]->number<<"  "<<globals::items[i]->name<<"    "<<globals::items[i]->price<<endl;
    }

    f1.close();

    globals::items[7]=new main_course(8,"Pizza(8inches) ", 340.0);
    globals::items[8]=new main_course(9,"Pizza(12inches)", 600.0);
    globals::items[9]=new main_course(10,"Lasagna", 750.0);
    globals::items[10]=new main_course(11,"Egg-Fried-Rice(Veg)", 200.0);
    globals::items[11]=new main_course(12,"Egg-Fried-Rice(Chicken/Prawn)", 230.0);
    globals::items[12]=new main_course(13,"Chicken-Burger", 250.0);
    globals::items[13]=new main_course(14,"Beef-Burger", 260.0);
    globals::items[14]=new main_course(15,"Veggie-Burger", 200.0);
    globals::items[15]=new main_course(16,"Steak(Sirloin)", 1700);
    globals::items[16]=new main_course(17,"Steak(Ribeye)", 1700);
    globals::items[17]=new main_course(18,"Beef-Sizzling", 260.0);
    globals::items[18]=new main_course(19,"Fried-Chicken", 260.0);
    globals::items[19]=new main_course(20,"Roasted-Salmon", 870.0);

    globals::mainNum=13;

    ofstream f2("maincourse.txt",ios::app);

    for(int i=7; i<20; i++)
    {
        f2<<globals::items[i]->number<<"  "<<globals::items[i]->name<<"    "<<globals::items[i]->price<<endl;
    }

    f2.close();

    globals::items[20]=new dessert(21,"Brownie", 140.0);
    globals::items[21]=new dessert(22,"Chocolate-Cake(Slice)", 250.0);
    globals::items[22]=new dessert(23,"Apple-Pie(Slice)", 150.0);
    globals::items[23]=new dessert(24,"Blueberry-Cheesecake(Slice)", 255.0);
    globals::items[24]=new dessert(25,"Red-Velvet-Cheesecake(Slice)", 240.0);
    globals::items[25]=new dessert(26,"Lava-Cake", 200.0);

    globals::desNum=6;

    ofstream f3("dessert.txt",ios::app);

    for(int i=20; i<26; i++)
    {
        f3<<globals::items[i]->number<<"  "<<globals::items[i]->name<<"    "<<globals::items[i]->price<<endl;
    }

    f3.close();

    globals::items[26]=new drinks(27,"Water", 15.0);
    globals::items[27]=new drinks(28,"Sparkling-Water", 100.0);
    globals::items[28]=new drinks(29,"Oreo-Shake", 180.0);
    globals::items[29]=new drinks(30,"Kitkat-Shake", 150.0);
    globals::items[30]=new drinks(31,"Hot-Chocolate", 180.0);
    globals::items[31]=new drinks(32,"Chocolate-Cold-Coffee", 150.0);
    globals::items[32]=new drinks(33,"Espresso", 120.0);
    globals::items[33]=new drinks(34,"Americano", 130.0);
    globals::items[34]=new drinks(35,"Lemon-Iced-Tea", 150.0);
    globals::items[35]=new drinks(36,"Earl-Grey", 150.0);
    globals::items[36]=new drinks(37,"Apple/Pineapple/Orange-Juice", 100.0);
    globals::items[37]=new drinks(38,"Martini", 220.0);
    globals::items[38]=new drinks(39,"Soft-Drink(CocaCola/Pepsi/7UP/Fanta/Mountain-Dew)",35.0);

    globals::drinkNum=13;

    ofstream f4("drinks.txt",ios::app);

    for(int i=26; i<39; i++)
    {
        f4<<globals::items[i]->number<<"  "<<globals::items[i]->name<<"    "<<globals::items[i]->price<<endl;
    }

    f4.close();

    globals::courseNum=39;
}

void showMenu()
{
    cout<<"\t\t\t STARTER:"<<endl;

    ifstream read("starter.txt");
    int number;
    string name;
    float price;

    while(read>>number>>name>>price)
    {
        cout<<"\t\t\t"<<number<<"   "<<name<<"  "<<price<<endl;
    }
    read.close();

    cout<<endl<<endl;
    cout<<"\t\t\t MAIN COURSE:"<<endl;

    ifstream read1("maincourse.txt");

    while(read1>>number>>name>>price)
    {
        cout<<"\t\t\t"<<number<<"   "<<name<<"  "<<price<<endl;
    }
    read1.close();

    cout<<endl<<endl;
    cout<<"\t\t\t DESSERT:"<<endl;

    ifstream read2("dessert.txt");

    while(read2>>number>>name>>price)
    {
        cout<<"\t\t\t"<<number<<"   "<<name<<"  "<<price<<endl;
    }
    read2.close();

    cout<<endl<<endl;
    cout<<"\t\t\t BEVERAGES:"<<endl;

    ifstream read3("drinks.txt");

    while(read3>>number>>name>>price)
    {
        cout<<"\t\t\t"<<number<<"   "<<name<<"  "<<price<<endl;
    }
    read3.close();
}


#endif // MENU_H_INCLUDED
