#ifndef CASHIERLOGIN_H_INCLUDED
#define CASHIERLOGIN_H_INCLUDED

#include <iostream>
#include <fstream>
#include <string>
#include <chrono>
#include <thread>
#include "myGlobals.h"
#include "menu.h"

using namespace std;

void cashierLogin(string user)
{
    using namespace std::this_thread;     // sleep_for, sleep_until
    using namespace std::chrono_literals; // ns, us, ms, s, h, etc.
    using std::chrono::system_clock;

    int choice=0;

    cout<<"\t\t\t1. Make bill."<<endl;
    cout<<"\t\t\t2. Show user information."<<endl;
    cout<<"\t\t\t3. See shift."<<endl;
    cout<<"\t\t\t4. See salary."<<endl;
    cout<<"\t\t\t5. See menu."<<endl;
    cout<<"\t\t\t6. Log out."<<endl<<endl;
    cout<<"\t\t\tEnter choice: ";
    cin>>choice;

    system("cls");

    if(choice==1)  /// make bill
    {
        string customer;  //cust name, food name, food id, price, quantity, total price
        char ch;
        int total=0;

        cout<<"Enter customer name: ";
        cin>>customer;
        string s= customer + "bill.txt";
        string current= "current" + s;

        ofstream fbill(s,ios::app);
        ofstream receipt(current);

        fbill<<"Receipt"<<endl<<endl;
        receipt<<"Receipt"<<endl<<endl;
        fbill<<"Customer name: "<<customer<<endl<<endl;
        receipt<<"Customer name: "<<customer<<endl<<endl;
        fbill<<"ID  Name                Price(in TK)   Amount"<<endl<<endl;
        receipt<<"ID  Name                Price(in TK)   Amount"<<endl<<endl;

        while(1)
        {
            int foodID;
            int quantity;

            cout<<"Enter food ID: ";
            cin>>foodID;
            cout<<"Enter quantity: ";
            cin>>quantity;
            // check if index foodID - 1 exists;
            fbill<<foodID<<"    "<<globals::items[foodID-1]->name<<"            "<<globals::items[foodID-1]->price<<"   "<<quantity<<endl;
            receipt<<foodID<<"    "<<globals::items[foodID-1]->name<<"            "<<globals::items[foodID-1]->price<<"   "<<quantity<<endl;
            total += (globals::items[foodID-1]->price ) * quantity;
            getchar();
            cout<<"Press [x] to stop taking orders."<<endl;
            cout<<"Press [c] to continue."<<endl;

            cin>>ch;
            if(ch=='x') break;
        }
        fbill<<endl<<endl;
        fbill<<"Total amount: TK "<<total<<endl<<endl;
        fbill<<"Thank you!"<<endl;

        fbill.close();

        receipt<<endl<<endl;
        receipt<<"Total amount: TK "<<total<<endl<<endl;
        receipt<<"Thank you!"<<endl;

        receipt.close();

        getchar();
        system("cls");
        cashierLogin(user);
    }
    else if(choice==2)  ///showInfo()
    {
        string s= user + ".txt";
        ifstream ifs(s);  //read

        string u, n, shif; //user, name, shift
        int age, id, sal;
        long long int phone;

        ifs>>u>>n>>age>>phone>>id>>shif>>sal;

        int idx=id-1;

        globals::emps[idx]->showInfo();

        getchar();
        getchar();
        system("cls");
        cashierLogin(user);

    }
    else if(choice==3)  /// see shift
    {
        string s= user + ".txt";
        ifstream ifs(s);

        string u, n, shif; //user, name, shift
        int age, id, sal;
        long long int phone;

        ifs>>u>>n>>age>>phone>>id>>shif>>sal;

        int idx=id-1;

        globals::emps[idx]->getShift();

        getchar();
        getchar();
        system("cls");
        cashierLogin(user);
    }
    else if(choice==4) ///see salary
    {
        string s= user + ".txt";
        ifstream ifs(s);

        string u, n, shif; //user, name, shift
        int age, id, sal;
        long long int phone;

        ifs>>u>>n>>age>>phone>>id>>shif>>sal;

        int idx=id-1;

        globals::emps[idx]->getSal();

        getchar();
        getchar();
        system("cls");
        cashierLogin(user);
    }
    else if(choice==5)  ///see menu
    {
        showMenu();
        getchar();
        getchar();
        system("cls");
        cashierLogin(user);
    }
    else if(choice==6)  ///log out
    {
        cout<<"\t\t\tLogging out."<<endl;
        sleep_for(2s);
        system("cls");
        return;
    }
    else
    {
        cout<<"\t\t\tInvalid choice. Please try again."<<endl;
        sleep_for(1s);
        system("cls");
        cashierLogin(user);
    }
}

#endif // CASHIERLOGIN_H_INCLUDED
