#ifndef SERVER_H
#define SERVER_H

#include <employee.h>


class server : public employee
{
    private:


    public:
        server(string user, string pass,int i);
        server(string user, string pass, string n, int a, long long int p,int i, string shif,int sal);
        virtual ~server();
        void showInfo();
        void showUser();
};

#endif // SERVER_H
