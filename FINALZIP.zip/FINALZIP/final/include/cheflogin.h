#ifndef CHEFLOGIN_H_INCLUDED
#define CHEFLOGIN_H_INCLUDED

#include <iostream>
#include <fstream>
#include <string>
#include <chrono>
#include <thread>
#include "myGlobals.h"
#include "menu.h"
#include "starter.h"
#include "maincourse.h"
#include "dessert.h"
#include "drinks.h"

using namespace std;

void modify(string user);
void chefLogin(string user);
void deletemaincourse()
{
}

void showStarter() {}
void showMainCourse() {}
void showDessert() {}
void showDrinks() {}

vector<starter> populate_array(string file_name, int type)
{
    globals::courseNum = globals::startNum + globals::mainNum + globals::desNum + globals::drinkNum;

    int cnum;
    int no_of_items;
    string cname;
    float cprice;
    vector<starter> vec;

    ifstream file(file_name);

    if (type == 1)
    {
        no_of_items = globals::startNum;
    }
    else if (type == 2)
    {
        no_of_items = globals::mainNum;
    }
    else if (type == 3)
    {
        no_of_items = globals::desNum;
    }
    else if (type == 4)
    {
        no_of_items = globals::drinkNum;
    }
    else
    {
    }

    for (int i = 0; i < no_of_items; i++)
    {
        file >> cnum >> cname >> cprice;

        vec.push_back(starter(cnum, cname, cprice));

        //cout<<vec[i].name<<" " <<vec[i].number<<" "<<vec[i].price<<endl;
    }

    file.close();
    return vec;
}

void deleteitem(int id, int type)
{
    string type_arr[] = {
        "starter",
        "maincourse",
        "dessert",
        "drinks"};

    string file_name = type_arr[type - 1] + ".txt";

    // open file

    // read all from file keep in arr
    vector<starter> vec = populate_array(file_name, type);
    /*populate array reads a file a type and returns a vector of starter.
    Starter vector is enough to handle the names id and price */

    ofstream file(file_name);

    for (auto item : vec)
    {
        if (item.number != id)
            file << item.number<<" " << item.name<<" "  << item.price<<'\n';
        // write all item to file
        // if item.id == id then dont

        //EDITEDDD
    }
}
void deleteoptions(string user)
{
    int opt;
    int item_type;
    cout << "\t\t\t1.Delete item of Starter." << endl;
    cout << "\t\t\t2.Delete item of Main Course." << endl;
    cout << "\t\t\t3.Delete item of Dessert." << endl;
    cout << "\t\t\t4.Delete item of Beverages." << endl<< endl;
    cout << "\t\t\tEnter option: ";
    cin >> opt;

    getchar();
    if (opt == 1)
    {
        showStarter();
    }
    else if (opt == 2)
    {

        showMainCourse();
    }
    else if (opt == 3)
    {
        showDessert();
    }
    else if (opt == 4)
    {
        showDrinks();
    }
    else
    {
        cout << "\t\t\tINVALID OPTION";
    }

    int item_to_delete;
    cout << "\t\t\tEnter ID of item to be deleted: ";
    cin >> item_to_delete;

    deleteitem(item_to_delete, opt);

    cout << "\t\t\tItem has been deleted. "<<endl;
    getchar();

}

void modifyItem(int id, string newname, double newprice, int type)
{

    string type_arr[] = {
        "starter",
        "maincourse",
        "dessert",
        "drinks"};

    string file_name = type_arr[type - 1] + ".txt";


    vector<starter> vec = populate_array(file_name, type);
    ofstream file(file_name);

    for (auto item : vec)
    {
        if (item.number == id)
        {
            item.name = newname;
            item.price = newprice;
        }
        file << item.number<<" "<< item.name<<" "<< item.price<<'\n';
        // write all item to file
        // if item.id == id then dont
    }

    // write all item to file
    // if item.id == id then
    //{item.name = newname
    // item.price = newprice }
}

void modifyoption(string user)
{
    int opt;
    int item_type;
    cout << "\t\t\t1.Modify item of Starter." << endl;
    cout << "\t\t\t2.Modify item of Main Course." << endl;
    cout << "\t\t\t3.Modify item of Dessert." << endl;
    cout << "\t\t\t4.Modify item of Beverages." << endl
         << endl;
    cout << "\t\t\tEnter option: ";
    cin >> opt;

    getchar();
    if (opt == 1)
    {

        showStarter();
    }
    else if (opt == 2)
    {

        showMainCourse();
    }
    else if (opt == 3)
    {
        showDessert();
    }
    else if (opt == 4)
    {
        showDrinks();
    }
    else
    {
        cout << "\t\t\tINVALID OPTION";
    }
    int item_to_modify;
    string newname;
    cout << "\t\t\tEnter ID of item to be modified: ";
    cin >> item_to_modify;
    cout << "\t\t\tEnter new name of item: ";
    cin >> newname;
    double price;
    cout << "\t\t\tEnter new price: ";
    cin >> price;

    modifyItem(item_to_modify, newname, price, opt);
}

void add(string user)
{
    int opt;

    cout << "\t\t\t1.Add new item to the Starter." << endl;
    cout << "\t\t\t2.Add new item to the Main Course." << endl;
    cout << "\t\t\t3.Add new item to the Dessert." << endl;
    cout << "\t\t\t4.Add new item to the Beverages." << endl<< endl;
    cout << "\t\t\tEnter option: ";
    cin >> opt;

    getchar();

    if (opt == 1) // starter
    {
        ofstream fstart("starter.txt", ios::app);
        int num;
        string name;
        float price;

        cout << "\t\t\tNew item name: ";
        cin >> name;
        cout << "\t\t\tNew item price: ";
        cin >> price;

        globals::startNum++;
        num = globals::courseNum + 1; // num=40

        fstart << num << "  " << name << "  " << price << endl;
        globals::items[globals::courseNum++] = new starter(num, name, price);

        fstart.close();
        getchar();
        system("cls");
    }
    else if (opt == 2) // main course
    {
        ofstream fmain("maincourse.txt", ios::app);
        int num;
        string name;
        float price;

        cout << "\t\t\tNew item name: ";
        cin >> name;
        cout << "\t\t\tNew item price: ";
        cin >> price;

        globals::mainNum++;
        num = globals::courseNum + 1;

        fmain << num << "  " << name << "  " << price << endl;
        globals::items[globals::courseNum++] = new main_course(num, name, price);

        fmain.close();
        getchar();
        system("cls");
    }
    else if (opt == 3) // dessert
    {
        ofstream fdes("dessert.txt", ios::app);
        int num;
        string name;
        float price;

        cout << "\t\t\tNew item name: ";
        cin >> name;
        cout << "\t\t\tNew item price: ";
        cin >> price;

        globals::desNum++;
        num = globals::courseNum + 1;

        fdes << num << "  " << name << "  " << price << endl;
        globals::items[globals::courseNum++] = new dessert(num, name, price);

        fdes.close();
        getchar();
        system("cls");
    }
    else if (opt == 4) // drinks
    {
        ofstream fdrink("drinks.txt", ios::app);
        int num;
        string name;
        float price;

        cout << "\t\t\tNew item name: ";
        cin >> name;
        cout << "\t\t\tNew item price: ";
        cin >> price;

        globals::drinkNum++;
        num = globals::courseNum + 1;

        fdrink << num << "  " << name << "  " << price << endl;
        globals::items[globals::courseNum++] = new drinks(num, name, price);

        fdrink.close();
        getchar();
        system("cls");
    }
    else
    {
        cout << "\t\t\tInvalid choice. Please try again." << endl;
        sleep_for(1s);
        system("cls");
        modify(user);
    }
}
void modify(string user)
{

    showMenu();

    cout << endl
         << endl;
    int opt;

    cout << "\t\t\t1.Add new item." << endl;
    cout << "\t\t\t2.Delete item." << endl;
    cout << "\t\t\t3.Modify item." << endl
         << endl;
    cout << "\t\t\tEnter option: ";
    cin >> opt;

    if (opt == 1)
    {
        add(user);
    }
    else if (opt == 2)
    {
        deleteoptions(user);
        globals::courseNum--;
    }
    else if (opt == 3)
    {
        modifyoption(user);
    }
    else
    {
        cout << "\t\t\tInvalid choice. Please try again." << endl;
        sleep_for(1s);
        system("cls");
        modify(user);
    }

    getchar();

    chefLogin(user);
}

void chefLogin(string user)
{
    using namespace std::this_thread;     // sleep_for, sleep_until
    using namespace std::chrono_literals; // ns, us, ms, s, h, etc.
    using std::chrono::system_clock;

    int choice = 0;

    cout << "\t\t\t1. Show user information." << endl;
    cout << "\t\t\t2. See shift." << endl;
    cout << "\t\t\t3. See salary." << endl;
    cout << "\t\t\t4. See menu." << endl;
    cout << "\t\t\t5. Update menu." << endl;
    cout << "\t\t\t6. Log out." << endl
         << endl;
    cout << "\t\t\tEnter choice: ";
    cin >> choice;

    system("cls");

    if (choice == 1)
    {
        /// showUser()

        string s = user + ".txt";
        ifstream ifs(s); // read

        string u, n, shif; // user, name, shift
        int age, id, sal;
        long long int phone;

        ifs >> u >> n >> age >> phone >> id >> shif >> sal;

        int idx = id - 1;

        globals::emps[idx]->showInfo();

        getchar();
        getchar();
        system("cls");
        chefLogin(user);
    }
    else if (choice == 2) // see shift
    {
        string s = user + ".txt";
        ifstream ifs(s);

        string u, n, shif; // user, name, shift
        int age, id, sal;
        long long int phone;

        ifs >> u >> n >> age >> phone >> id >> shif >> sal;

        int idx = id - 1;

        globals::emps[idx]->getShift();

        getchar();
        getchar();
        system("cls");
        chefLogin(user);
    }
    else if (choice == 3) // see salary
    {
        string s = user + ".txt";
        ifstream ifs(s);

        string u, n, shif; // user, name, shift
        int age, id, sal;
        long long int phone;

        ifs >> u >> n >> age >> phone >> id >> shif >> sal;

        int idx = id - 1;

        globals::emps[idx]->getSal();

        getchar();
        getchar();
        system("cls");
        chefLogin(user);
    }
    else if (choice == 4) // see menu
    {
        showMenu();
        getchar();
        getchar();
        system("cls");
        chefLogin(user);
    }
    else if (choice == 5) // update menu
    {
        modify(user);
    }
    else if (choice == 6) // log out
    {
        cout << "\t\t\tLogging out." << endl;
        sleep_for(2s);
        system("cls");
        return;
    }
    else
    {
        cout << "\t\t\tInvalid choice. Please try again." << endl;
        sleep_for(1s);
        system("cls");
        chefLogin(user);
    }
}

#endif // CHEFLOGIN_H_INCLUDED
