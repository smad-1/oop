#ifndef CASHIER_H
#define CASHIER_H

#include <employee.h>


class cashier : public employee
{
    private:


    public:
        cashier(string user, string pass,int i);
        cashier(string user, string pass, string n, int a, long long int p,int i, string shif,int sal);
        virtual ~cashier();
        void showInfo();
        void showUser();
};

#endif // CASHIER_H
