#ifndef SUPPLY_PRODUCTS_H_INCLUDED
#define SUPPLY_PRODUCTS_H_INCLUDED

#include <iostream>
#include "myGlobals.h"

using namespace std;

void setSupply()
{
    globals::prods[0]=new products("Mr.X",123,30,1,1,"Sugar",100.00);
    globals::prods[1]=new products("Mr.X",123,30,1,2,"Salt",100.00);
    globals::prods[2]=new products("Mr.Y",321,35,2,3,"Spices",150.00);
    globals::prods[3]=new products("Mr.Y",321,35,2,4,"Utensils",150.00);
    globals::prods[4]=new products("Mr.Z",456,40,3,5,"Beverages",50.00);
    globals::prods[5]=new products("Mr.Z",456,40,3,6,"Meat",200.00);
    globals::prods[6]=new products("Mr.A",654,29,4,7,"Flour",175.00);
    globals::prods[7]=new products("Mr.A",654,29,4,8,"Oil",250.00);
    globals::prods[8]=new products("Mr.B",789,45,5,9,"Fish",300.00);
}

#endif // SUPPLY_PRODUCTS_H_INCLUDED
