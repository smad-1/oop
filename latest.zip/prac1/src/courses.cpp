#include "courses.h"

using namespace std;

courses::courses(int num, string n, float p)
{
    number=num;
    name=n;
    price=p;
}

courses::~courses()
{
    //dtor
}
