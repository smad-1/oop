#include <bits/stdc++.h>
#ifndef MAINCOURSE_H
#define MAINCOURSE_H

#include "courses.h"

using namespace std;

class main_course : public courses
{
    public:
        main_course(int num, string n, float p):courses(num,n,p)
        {

        }
        void showCourse()
        {
            cout<<number<<".    "<<name<<"    TK "<<price<<endl;
        }

};

#endif
