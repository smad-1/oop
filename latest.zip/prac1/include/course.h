#ifndef EMPLOYEE_H
#define EMPLOYEE_H
#include <iostream>
#include <fstream>

#pragma once

using namespace std;

class courses{
public:
    string name;
    float price;
    int number;

    courses(){}
    courses(int num, string n, float p);
    virtual void showCourse()=0;

};

#endif
