#ifndef MANAGERLOGIN_H_INCLUDED
#define MANAGERLOGIN_H_INCLUDED

#include <iostream>
#include <fstream>
#include <string>
#include <chrono>
#include <thread>
#include "myGlobals.h"

using namespace std;

void managerLogin(string user)
{
    using namespace std::this_thread;     // sleep_for, sleep_until
    using namespace std::chrono_literals; // ns, us, ms, s, h, etc.
    using std::chrono::system_clock;

    int choice=0;

    cout<<"\t\t\t1. Show user information."<<endl;
    cout<<"\t\t\t2. Show employee information."<<endl;
    cout<<"\t\t\t3. Set employee shift."<<endl;
    cout<<"\t\t\t4. Set employee salary."<<endl;
    cout<<"\t\t\t5. Log out."<<endl<<endl;
    cout<<"\t\t\tEnter choice: ";
    cin>>choice;

    system("cls");

    if(choice==1)
    {
        ///showUser()

        string s= user + ".txt";
        ifstream ifs(s);

        string u, n, shif; //user, name, shift
        int age, id, sal;
        long long int phone;

        ifs>>u>>n>>age>>phone>>id>>shif>>sal;

        int idx=id-1;

        globals::emps[idx]->showUser();

        getchar();
        getchar();
        system("cls");
        managerLogin(user);

    }
    else if(choice==2)
    {
        ///showempinfo

        cout<< "Employee Count: "<<globals::emp_count<<endl<<endl;
        for(int i=0; i<globals::emp_count; i++)
        {
            cout<<"Employee "<<i+1<<":"<<endl;
            globals::emps[i]->showUser();
            cout<<endl<<endl;
        }
        getchar();
        getchar();
        system("cls");
        managerLogin(user);
    }
    else if(choice==3)
    {
        ///set shift

        int op;
        cout<<"\t\t\tSet shift for: "<<endl<<endl;
        cout<<"\t\t\t1. Cashier. "<<endl;
        cout<<"\t\t\t2. Chef. "<<endl;
        cout<<"\t\t\t3. Server. "<<endl<<endl;
        cout<<"Enter option: ";
        cin>>op;

        if(op==1) //cashier
        {
            ifstream countuser("cashier.txt"); //read
            string lines;
            int cashcount=0;

            if(countuser.is_open())
            {
                while(countuser.peek()!=EOF)
                {
                    getline(countuser,lines);
                    cashcount++;
                }
                countuser.close();
            }

            cout<<"Cashiers: "<<endl;

            string nam,pass;
            ifstream getuser("cashier.txt");  //read          getuser,individual
            for(int i=0; i<cashcount; i++)
            {
                getuser>>nam>>pass;
                string s= nam + ".txt";

                ifstream individual(s);   // file of individual employee, has all info

                string u, n, shif; //user, name, shift
                int age, id, sal;
                long long int phone;

                individual>>u>>n>>age>>phone>>id>>shif>>sal;

                cout<<"ID: "<<id<<" Name: "<<n<<" Username:"<<u<<endl;

                individual.close();

            }
            getuser.close();

            string check;
            cout<<"Enter username of cashier: ";
            cin>>check;
            check = check + ".txt";

            string u, n, shif; //user, name, shift
            int age, id, sal;
            long long int phone;

            ifstream newfile(check);
            newfile>>u>>n>>age>>phone>>id>>shif>>sal;
            newfile.close();

            string newshift;
            cout<<"Enter new shift for cashier: ";
            cin>>newshift;

            ofstream ofs(check, ios::out | ios::trunc);  //WRITE + TRUNCATE
            ofs<<u<<endl;
            ofs<<n<<endl;
            ofs<<age<<endl;
            ofs<<phone<<endl;
            ofs<<id<<endl;
            ofs<<newshift<<endl;
            ofs<<sal<<endl;

            ofs.close();

            globals::emps[id-1]= new cashier(nam,pass,n,age,phone,id,newshift,sal);

            system("cls");
            managerLogin(user);
        }
        else if(op==2) // CHEF
        {
            ifstream countuser("chef.txt"); //read
            string lines;
            int chefcount=0;

            if(countuser.is_open())
            {
                while(countuser.peek()!=EOF)
                {
                    getline(countuser,lines);
                    chefcount++;
                }
                countuser.close();
            }

            cout<<"Chefs: "<<endl;

            string nam,pass;
            ifstream getuser("chef.txt");  //read          getuser,individual
            for(int i=0; i<chefcount; i++)
            {
                getuser>>nam>>pass;
                string s= nam + ".txt";

                ifstream individual(s);   // file of individual employee, has all info

                string u, n, shif; //user, name, shift
                int age, id, sal;
                long long int phone;

                individual>>u>>n>>age>>phone>>id>>shif>>sal;

                cout<<"ID: "<<id<<" Name: "<<n<<" Username:"<<u<<endl;

                individual.close();

            }
            getuser.close();

            string check;
            cout<<"Enter username of chef: ";
            cin>>check;
            check = check + ".txt";

            string u, n, shif; //user, name, shift
            int age, id, sal;
            long long int phone;

            ifstream newfile(check);
            newfile>>u>>n>>age>>phone>>id>>shif>>sal;
            newfile.close();

            string newshift;
            cout<<"Enter new shift for chef: ";
            cin>>newshift;

            ofstream ofs(check, ios::out | ios::trunc);  //WRITE + TRUNCATE
            ofs<<u<<endl;
            ofs<<n<<endl;
            ofs<<age<<endl;
            ofs<<phone<<endl;
            ofs<<id<<endl;
            ofs<<newshift<<endl;
            ofs<<sal<<endl;

            ofs.close();

            globals::emps[id-1]= new cashier(nam,pass,n,age,phone,id,newshift,sal);

            system("cls");
            managerLogin(user);
        }
        else if(op==3) //SERVER
        {
            ifstream countuser("server.txt"); //read
            string lines;
            int servcount=0;

            if(countuser.is_open())
            {
                while(countuser.peek()!=EOF)
                {
                    getline(countuser,lines);
                    servcount++;
                }
                countuser.close();
            }

            cout<<"Servers: "<<endl;

            string nam,pass;
            ifstream getuser("server.txt");  //read          getuser,individual
            for(int i=0; i<servcount; i++)
            {
                getuser>>nam>>pass;
                string s= nam + ".txt";

                ifstream individual(s);   // file of individual employee, has all info


                string u, n, shif; //user, name, shift
                int age, id, sal;
                long long int phone;

                individual>>u>>n>>age>>phone>>id>>shif>>sal;

                cout<<"ID: "<<id<<" Name: "<<n<<" Username:"<<u<<endl;

                individual.close();

            }
            getuser.close();

            string check;
            cout<<"Enter username of server: ";
            cin>>check;
            check = check + ".txt";

            string u, n, shif; //user, name, shift
            int age, id, sal;
            long long int phone;

            ifstream newfile(check);
            newfile>>u>>n>>age>>phone>>id>>shif>>sal;
            newfile.close();

            string newshift;
            cout<<"Enter new shift for server: ";
            cin>>newshift;

            ofstream ofs(check, ios::out | ios::trunc);  //WRITE + TRUNCATE
            ofs<<u<<endl;
            ofs<<n<<endl;
            ofs<<age<<endl;
            ofs<<phone<<endl;
            ofs<<id<<endl;
            ofs<<newshift<<endl;
            ofs<<sal<<endl;

            ofs.close();

            globals::emps[id-1]= new cashier(nam,pass,n,age,phone,id,newshift,sal);

            system("cls");
            managerLogin(user);
        }
        else
        {
            cout<<"Invalid choice. Please try again."<<endl;
            sleep_for(2s);
            system("cls");
            managerLogin(user);
        }
    }
    else if(choice==4)
    {
        ///set salary

        int op;
        cout<<"\t\t\tSet salary for: "<<endl<<endl;
        cout<<"\t\t\t1. Cashier. "<<endl;
        cout<<"\t\t\t2. Chef. "<<endl;
        cout<<"\t\t\t3. Server. "<<endl<<endl;
        cout<<"Enter option: ";
        cin>>op;

        if(op==1) //cashier
        {
            ifstream countuser("cashier.txt"); //read
            string lines;
            int cashcount=0;

            if(countuser.is_open())
            {
                while(countuser.peek()!=EOF)
                {
                    getline(countuser,lines);
                    cashcount++;
                }
                countuser.close();
            }

            cout<<"Cashiers: "<<endl;

            string nam,pass;
            ifstream getuser("cashier.txt");  //read          getuser,individual
            for(int i=0; i<cashcount; i++)
            {
                getuser>>nam>>pass;
                string s= nam + ".txt";

                ifstream individual(s);   // file of individual employee, has all info

                string u, n, shif; //user, name, shift
                int age, id, sal;
                long long int phone;

                individual>>u>>n>>age>>phone>>id>>shif>>sal;

                cout<<"ID: "<<id<<"  Name: "<<n<<"  Username:"<<u<<endl;

                individual.close();

            }
            getuser.close();

            string check;
            cout<<"Enter username of cashier: ";
            cin>>check;
            check = check + ".txt";

            string u, n, shif; //user, name, shift
            int age, id, sal;
            long long int phone;

            ifstream newfile(check);
            newfile>>u>>n>>age>>phone>>id>>shif>>sal;
            newfile.close();

            int newsalary;
            cout<<"Enter new salary for cashier: ";
            cin>>newsalary;

            ofstream ofs(check, ios::out | ios::trunc);  //WRITE + TRUNCATE
            ofs<<u<<endl;
            ofs<<n<<endl;
            ofs<<age<<endl;
            ofs<<phone<<endl;
            ofs<<id<<endl;
            ofs<<shif<<endl;
            ofs<<newsalary<<endl;

            ofs.close();

            globals::emps[id-1]= new cashier(nam,pass,n,age,phone,id,shif,newsalary);

            managerLogin(user);
        }
        else if(op==2) // CHEF
        {
            ifstream countuser("chef.txt"); //read
            string lines;
            int chefcount=0;

            if(countuser.is_open())
            {
                while(countuser.peek()!=EOF)
                {
                    getline(countuser,lines);
                    chefcount++;
                }
                countuser.close();
            }

            cout<<"Chefs: "<<endl;

            string nam,pass;
            ifstream getuser("chef.txt");  //read          getuser,individual
            for(int i=0; i<chefcount; i++)
            {
                getuser>>nam>>pass;
                string s= nam + ".txt";

                ifstream individual(s);   // file of individual employee, has all info

                string u, n, shif; //user, name, shift
                int age, id, sal;
                long long int phone;

                individual>>u>>n>>age>>phone>>id>>shif>>sal;

                cout<<"ID: "<<id<<" Name: "<<n<<" Username:"<<u<<endl;

                individual.close();

            }
            getuser.close();

            string check;
            cout<<"Enter username of chef: ";
            cin>>check;
            check = check + ".txt";

            string u, n, shif; //user, name, shift
            int age, id, sal;
            long long int phone;

            ifstream newfile(check);
            newfile>>u>>n>>age>>phone>>id>>shif>>sal;
            newfile.close();

            int newsalary;
            cout<<"Enter new salary for chef: ";
            cin>>newsalary;

            ofstream ofs(check, ios::out | ios::trunc);  //WRITE + TRUNCATE
            ofs<<u<<endl;
            ofs<<n<<endl;
            ofs<<age<<endl;
            ofs<<phone<<endl;
            ofs<<id<<endl;
            ofs<<shif<<endl;
            ofs<<newsalary<<endl;

            ofs.close();

            globals::emps[id-1]= new cashier(nam,pass,n,age,phone,id,shif,newsalary);

            managerLogin(user);
        }
        else if(op==3) //SERVER
        {
            ifstream countuser("server.txt"); //read
            string lines;
            int servcount=0;

            if(countuser.is_open())
            {
                while(countuser.peek()!=EOF)
                {
                    getline(countuser,lines);
                    servcount++;
                }
                countuser.close();
            }

            cout<<"Servers: "<<endl;

            string nam,pass;
            ifstream getuser("server.txt");  //read          getuser,individual
            for(int i=0; i<servcount; i++)
            {
                getuser>>nam>>pass;
                string s= nam + ".txt";

                ifstream individual(s);   // file of individual employee, has all info


                string u, n, shif; //user, name, shift
                int age, id, sal;
                long long int phone;

                individual>>u>>n>>age>>phone>>id>>shif>>sal;

                cout<<"ID: "<<id<<" Name: "<<n<<" Username:"<<u<<endl;

                individual.close();

            }
            getuser.close();

            string check;
            cout<<"Enter username of server: ";
            cin>>check;
            check = check + ".txt";

            string u, n, shif; //user, name, shift
            int age, id, sal;
            long long int phone;

            ifstream newfile(check);
            newfile>>u>>n>>age>>phone>>id>>shif>>sal;
            newfile.close();

            int newsalary;
            cout<<"Enter new salary for server: ";
            cin>>newsalary;

            ofstream ofs(check, ios::out | ios::trunc);  //WRITE + TRUNCATE
            ofs<<u<<endl;
            ofs<<n<<endl;
            ofs<<age<<endl;
            ofs<<phone<<endl;
            ofs<<id<<endl;
            ofs<<shif<<endl;
            ofs<<newsalary<<endl;

            ofs.close();

            globals::emps[id-1]= new cashier(nam,pass,n,age,phone,id,shif,newsalary);

            managerLogin(user);
        }
        else
        {
            cout<<"Invalid choice. Please try again."<<endl;
            sleep_for(2s);
            system("cls");
            managerLogin(user);
        }
    }
    else if(choice==5) //exit
    {
        cout<<"\t\t\tLogging out."<<endl;
        sleep_for(2s);
        system("cls");
        return;
    }
    else
    {
        cout<<"\t\t\tInvalid choice. Please try again."<<endl;
        sleep_for(2s);
        system("cls");
        managerLogin(user);
    }
}

#endif // MANAGERLOGIN_H_INCLUDED
