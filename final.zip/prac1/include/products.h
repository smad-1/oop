#ifndef PRODUCTS_H
#define PRODUCTS_H

#include <supplier.h>


class products : public supplier
{
    public:
        int prod_id;
        string prod_name;
        float prod_price;

        products(string n, long long int p, int a, int idx1, int pid, string pname, float pprice);
        virtual ~products();
        void getInfo();

};

#endif // PRODUCTS_H
