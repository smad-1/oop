#ifndef MYGLOBALS_H_INCLUDED
#define MYGLOBALS_H_INCLUDED

#include <unordered_map>
#include "employee.h"
#include "courses.h"
#include "products.h"

#pragma once

namespace globals{

  extern employee* emps[100];           ///EMPLOYEE MANAGEMENT
  extern int emp_count;
  extern unordered_map <int,bool> checkID;
  extern int maxID;

  extern courses* items[100];           /// MENU
  extern int courseNum;
  extern int startNum;
  extern int mainNum;
  extern int desNum;
  extern int drinkNum;

  extern products* prods[10];           ///SUPPLY_PRODUCTS

}

#endif // MYGLOBALS_H_INCLUDED
