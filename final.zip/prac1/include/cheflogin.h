#ifndef CHEFLOGIN_H_INCLUDED
#define CHEFLOGIN_H_INCLUDED

#include <iostream>
#include <fstream>
#include <string>
#include <chrono>
#include <thread>
#include "myGlobals.h"
#include "menu.h"

using namespace std;

void chefLogin(string user)
{
    using namespace std::this_thread;     // sleep_for, sleep_until
    using namespace std::chrono_literals; // ns, us, ms, s, h, etc.
    using std::chrono::system_clock;

    int choice=0;

    cout<<"\t\t\t1. Show user information."<<endl;
    cout<<"\t\t\t2. See shift."<<endl;
    cout<<"\t\t\t3. See salary."<<endl;
    cout<<"\t\t\t4. See menu."<<endl;
    cout<<"\t\t\t5. Update menu."<<endl;
    cout<<"\t\t\t6. Log out."<<endl<<endl;
    cout<<"\t\t\tEnter choice: ";
    cin>>choice;

    system("cls");

    if(choice==1)
    {
        ///showInfo()

        string s= user + ".txt";
        ifstream ifs(s);  //read

        string u, n, shif; //user, name, shift
        int age, id, sal;
        long long int phone;

        ifs>>u>>n>>age>>phone>>id>>shif>>sal;

        int idx=id-1;

        globals::emps[idx]->showInfo();

        getchar();
        getchar();
        system("cls");
        chefLogin(user);

    }
    else if(choice==2)  // see shift
    {
        string s= user + ".txt";
        ifstream ifs(s);

        string u, n, shif; //user, name, shift
        int age, id, sal;
        long long int phone;

        ifs>>u>>n>>age>>phone>>id>>shif>>sal;

        int idx=id-1;

        globals::emps[idx]->getShift();

        getchar();
        getchar();
        system("cls");
        chefLogin(user);
    }
    else if(choice==3) //see salary
    {
        string s= user + ".txt";
        ifstream ifs(s);

        string u, n, shif; //user, name, shift
        int age, id, sal;
        long long int phone;

        ifs>>u>>n>>age>>phone>>id>>shif>>sal;

        int idx=id-1;

        globals::emps[idx]->getSal();

        getchar();
        getchar();
        system("cls");
        chefLogin(user);
    }
    else if(choice==4)  //see menu
    {
        showMenu();
        getchar();
        getchar();
        system("cls");
        chefLogin(user);
    }
    else if(choice==5)  //update menu
    {
        showMenu();
        cout<<endl<<endl;

        int opt;
        cout<<"\t\t\t1.Add new item to the Starter."<<endl;
        cout<<"\t\t\t2.Add new item to the Main Course."<<endl;
        cout<<"\t\t\t3.Add new item to the Dessert."<<endl;
        cout<<"\t\t\t4.Add new item to the Beverages."<<endl<<endl;
        cout<<"\t\t\tEnter option: ";
        cin>>opt;

        getchar();

        if(opt==1) //starter
        {
            ofstream fstart("starter.txt",ios::app);
            int num;
            string name;
            float price;

            cout<<"\t\t\tNew item name: ";
            cin>>name;
            cout<<"\t\t\tNew item price: ";
            cin>>price;

            globals::startNum++;
            num=globals::courseNum + 1;  //num=40

            fstart<<num<<"  "<<name<<"  "<<price<<endl;
            globals::items[globals::courseNum++]= new starter(num,name,price);

            fstart.close();
            getchar();
            getchar();
            system("cls");

        }
        else if(opt==2)  //main course
        {
            ofstream fmain("maincourse.txt",ios::app);
            int num;
            string name;
            float price;

            cout<<"\t\t\tNew item name: ";
            cin>>name;
            cout<<"\t\t\tNew item price: ";
            cin>>price;

            globals::mainNum++;
            num=globals::courseNum + 1;

            fmain<<num<<"  "<<name<<"  "<<price<<endl;
            globals::items[globals::courseNum++]= new main_course(num,name,price);

            fmain.close();
            getchar();
            getchar();
            system("cls");
        }
        else if(opt==3)  //dessert
        {
            ofstream fdes("dessert.txt",ios::app);
            int num;
            string name;
            float price;

            cout<<"\t\t\tNew item name: ";
            cin>>name;
            cout<<"\t\t\tNew item price: ";
            cin>>price;

            globals::desNum++;
            num=globals::courseNum + 1;

            fdes<<num<<"  "<<name<<"  "<<price<<endl;
            globals::items[globals::courseNum++]= new dessert(num,name,price);

            fdes.close();
            getchar();
            getchar();
            system("cls");
        }
        else if(opt==4)  //drinks
        {
            ofstream fdrink("drinks.txt",ios::app);
            int num;
            string name;
            float price;

            cout<<"\t\t\tNew item name: ";
            cin>>name;
            cout<<"\t\t\tNew item price: ";
            cin>>price;

            globals::drinkNum++;
            num=globals::courseNum + 1;

            fdrink<<num<<"  "<<name<<"  "<<price<<endl;
            globals::items[globals::courseNum++]= new drinks(num,name,price);

            fdrink.close();
            getchar();
            getchar();
            system("cls");
        }
        else  // wrong
        {
            cout<<"\t\t\tInvalid choice. Please try again."<<endl;
            sleep_for(1s);
            system("cls");
        }

        chefLogin(user);
    }
    else if(choice==6)  //log out
    {
        cout<<"\t\t\tLogging out."<<endl;
        sleep_for(2s);
        system("cls");
        return;
    }
    else
    {
        cout<<"\t\t\tInvalid choice. Please try again."<<endl;
        sleep_for(1s);
        system("cls");
        chefLogin(user);
    }
}

#endif // CHEFLOGIN_H_INCLUDED
