#ifndef SUPPLIER_H
#define SUPPLIER_H

#include <iostream>
using namespace std;

class supplier
{
    public:
        string supp_name;
        int age;
        long long int phone;
        int supp_id;

        supplier(string n, long long int p, int a, int idx);
        ~supplier();

};

#endif // SUPPLIER_H
