#ifndef COURSES_H
#define COURSES_H

#include <iostream>
#pragma once

using namespace std;

class courses
{
   public:
    string name;
    float price;
    int number;

    courses();
    ~courses();
    courses(int num, string n, float p);
    virtual void showCourse()=0;

};

#endif // COURSES_H
