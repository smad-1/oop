#include <iostream>
#include <string>
#include <chrono>
#include <thread>
#include <fstream>
#include "person.h"
#include "signup.h"
//#include "myGlobals.h"
#include "managerlogin.h"
#include "cheflogin.h"
#include "cashierlogin.h"
#include "serverlogin.h"
#include "menu.h"
#include "supply_products.h"

namespace globals{

  employee* emps[100];
  int emp_count=0;
  unordered_map <int,bool> checkID;
  int maxID=0;

  courses* items[100];
  int courseNum=0;
  int startNum=0;
  int mainNum=0;
  int desNum=0;
  int drinkNum=0;

  products* prods[10];
}

using namespace std;

int main(void)
{
  using namespace std::this_thread;     // sleep_for, sleep_until
  using namespace std::chrono_literals; // ns, us, ms, s, h, etc.
  using std::chrono::system_clock;

    ///update value of emp_count every time program is ran

    ifstream countuser("records.txt"); //read
    string lines;
    globals::emp_count=0;
    if(countuser.is_open())
    {
        while(countuser.peek()!=EOF)
        {
            getline(countuser,lines);
            globals::emp_count++;
        }
        countuser.close();
    }

    ///update emps[] every time program is ran

    if(globals::emp_count != 0)
    {
        ifstream read("records.txt");
        string empvar,emppass;
        for(int i=0; i<globals::emp_count; i++)
        {
            read>>empvar>>emppass;
            string ss= empvar + ".txt";

            ifstream r_emp(ss);
            string us,name,shift;
            int age,id,sal;
            long long int phone;

            r_emp>>us>>name>>age>>phone>>id>>shift>>sal;  //empvar=us

            string check;
            ifstream cman("manager.txt");
            while(cman>>check)
            {
                if(check==us)
                {
                    globals::emps[id-1] = new manager(empvar,emppass,name,age,phone,id,shift,sal);
                }
            }
            cman.close();

            ifstream cchef("chef.txt");
            while(cchef>>check)
            {
                if(check==us)
                {
                    globals::emps[id-1] = new chef(empvar,emppass,name,age,phone,id,shift,sal);
                }
            }
            cchef.close();

            ifstream ccash("cashier.txt");
            while(ccash>>check)
            {
                if(check==us)
                {
                    globals::emps[id-1] = new cashier(empvar,emppass,name,age,phone,id,shift,sal);
                }
            }
            ccash.close();

            ifstream cser("server.txt");
            while(cser>>check)
            {
                if(check==us)
                {
                    globals::emps[id-1] = new server(empvar,emppass,name,age,phone,id,shift,sal);
                }
            }

            globals::checkID[id]=true;

            cser.close();
            r_emp.close();
        }
        read.close();
    }

    ///update menu every time program is ran

    ifstream rstart("starter.txt");
    ifstream rmain("maincourse.txt");
    ifstream rdes("dessert.txt");
    ifstream rdrink("drinks.txt");

    if(rstart.is_open())
    {
        while(rstart.peek()!=EOF)
        {
            getline(rstart,lines);      //counts number of starters
            globals::startNum++;
        }
        rstart.close();
    }

    if(rmain.is_open())
    {
        while(rmain.peek()!=EOF)
        {
            getline(rmain,lines);      //counts number of main courses
            globals::mainNum++;
        }
        rmain.close();
    }

    if(rdes.is_open())
    {
        while(rdes.peek()!=EOF)
        {
            getline(rdes,lines);      //counts number of desserts
            globals::desNum++;
        }
        rdes.close();
    }

    if(rdrink.is_open())
    {
        while(rdrink.peek()!=EOF)
        {
            getline(rdrink,lines);      //counts number of drinks
            globals::drinkNum++;
        }
        rdrink.close();
    }

    if(globals::startNum==0 && globals::mainNum==0 && globals::desNum==0 && globals::drinkNum==0) // create menu
    {
        createMenu();
    }
    else
    {
        globals::courseNum= globals::startNum + globals::mainNum + globals::desNum + globals::drinkNum;
        int cnum;
        string cname;
        float cprice;

        ifstream start("starter.txt");

        for(int i=0; i<globals::startNum; i++)
        {
            start>>cnum>>cname>>cprice;

            globals::items[cnum-1]=new starter(cnum,cname,cprice);
        }
        start.close();

        ifstream mainc("maincourse.txt");

        for(int i=0; i<globals::mainNum; i++)
        {
            mainc>>cnum>>cname>>cprice;

            globals::items[cnum-1]=new main_course(cnum,cname,cprice);
        }
        mainc.close();

        ifstream dess("dessert.txt");

        for(int i=0; i<globals::desNum; i++)
        {
            dess>>cnum>>cname>>cprice;

            globals::items[cnum-1]=new dessert(cnum,cname,cprice);
        }
        dess.close();

        ifstream drink("drinks.txt");

        for(int i=0; i<globals::drinkNum; i++)
        {
            drink>>cnum>>cname>>cprice;

            globals::items[cnum-1]=new drinks(cnum,cname,cprice);
        }
        drink.close();
    }

    ///update supplier info every time program is ran

    setSupply();

  int choice;
  cout<<"\t\t\t________________________________\n\n";
  cout<<"\t\t\t   WELCOME TO THE LOGIN PAGE     \n\n";
  cout<<"\t\t\t________________________________\n\n\n";
  cout<<"\t\t\t1. Login."<<endl;
  cout<<"\t\t\t2. Sign up."<<endl;
  cout<<"\t\t\t3. Forgot password."<<endl;
  cout<<"\t\t\t4. Exit.\n"<<endl;
  cout<<"\t\t\tEnter choice: ";
  cin>>choice;
  cout<<endl;

  system("cls");

  int option; // for logging in
  string userID, userPass;

  switch(choice)
  {
  case 1:
    {
        sleep_for(1s);
        cout<<"\t\t\t1. Login as Manager."<<endl;
        cout<<"\t\t\t2. Login as Chef."<<endl;
        cout<<"\t\t\t3. Login as Cashier."<<endl;
        cout<<"\t\t\t4. Login as Server."<<endl<<endl;
        cout<<"\t\t\tEnter choice: ";

        cin>>option;

        system("cls");

        cout<<"\t\t\t LOGIN PAGE   \n\n";
        cout<<"\t\t\tEnter username: ";
        cin>>userID;
        cout<<"\t\t\tEnter password: ";
        cin>>userPass;

        bool log=login(option,userID,userPass);

        if(log) break;
        else main();
    }
  case 2:
    {
        sleep_for(1s);
        string title;
        cout<<"\t\t\tJob Title (manager/chef/cashier/server): ";
        cin>>title;
        register_(title);
        main();
        break;
    }
  case 3:
    {
        cout<<"forgot pass"<<endl;
        break;
    }
  case 4:
    {
        cout<<"\t\t\tExiting home page. Thank You!\n\n";
        break;
    }
  default:
    {
       // system("cls");
        cout<<"\t\t\tInvalid choice.\n\n";
        sleep_for(1s);
        system("cls");
        main();
    }
  }

  if(option==1)  // manager log in
  {
    sleep_for(1s);
    system("cls");
    managerLogin(userID);
    main();
  }
  else if(option==2)  // chef log in
  {
    sleep_for(1s);
    system("cls");
    cout<<"\t\t\t________________________________\n\n";
    cout<<"\t\t\t   Logged in as CHEF.     \n\n\n";
    cout<<"\t\t\t________________________________\n\n";
    chefLogin(userID);
    main();
  }
  else if(option==3)  // cashier log in
  {
    sleep_for(1s);
    system("cls");
    cout<<"\t\t\t________________________________\n\n";
    cout<<"\t\t\t   Logged in as CASHIER.     \n\n\n";
    cout<<"\t\t\t________________________________\n\n";
    cashierLogin(userID);
    main();
  }
  else if(option==4) // server log in
  {
    sleep_for(1s);
    system("cls");
    cout<<"\t\t\t________________________________\n\n";
    cout<<"\t\t\t   Logged in as SERVER.     \n\n\n";
    cout<<"\t\t\t________________________________\n\n";
    serverLogin(userID);
    main();
  }
  else  //wrong
  {
      cout<<"\t\t\tInvalid choice."<<endl;
      sleep_for(1s);
      system("cls");
      main();

  }




    return 0;
} // namespace std;
