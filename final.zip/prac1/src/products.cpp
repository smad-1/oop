#include "products.h"

products::products(string n, long long int p, int a, int idx1, int pid, string pname, float pprice):supplier(n,p,a,idx1)
{
    prod_id=pid;
    prod_name=pname;
    prod_price=pprice;
}

products::~products()
{
    //dtor
}

void products::getInfo()
{
    cout<<"Supplier name: "<<supp_name<<endl;
    cout<<"Supplier ID: "<<supp_id<<endl;
    cout<<"Supplier age: "<<age<<endl;
    cout<<"Mobile: "<<phone<<endl;
    cout<<"Product ID: "<<prod_id<<endl;
    cout<<"Product name: "<<prod_name<<endl;
    cout<<"Product price: "<<prod_price<<endl<<endl;
}
