#include "employee.h"
#include <fstream>
#include <iostream>
#include <string.h>
#include "myGlobals.h"
//#include "person.cpp"
//#include "person.h"

using namespace std;

employee::employee(string user, string pass, int i): person()
{
    ID=i;
    username=user;
    shift="NULL";
    password=pass;
    salary=0;
}

employee::~employee()
{

}
void employee::setInfo()
{
    string s= username + ".txt";
    ofstream fp(s,ios::app);

    string firstname, lastname;
    cout<<"\t\t\tFirst Name: ";
    cin>>firstname;
    cout<<"\t\t\tLast Name: ";
    cin>>lastname;

    name = firstname + lastname;
    fp<<name<<endl;

    getchar();
    cout<<"\t\t\tAge: ";
    cin>>age;
    fp<<age<<endl;

    getchar();
    cout<<"\t\t\tPhone number: ";
    cin>>phone;
    fp<<phone<<endl;

    getchar();
    cout<<"\t\t\tEmployee ID: "<<ID;
    fp<<ID<<endl;

    getchar();
    cout<<"\t\t\tShift: ";
    cin>>shift;
    fp<<shift<<endl;

    getchar();
    cout<<"\t\t\tSalary: ";
    cin>>salary;
    fp<<salary<<endl;

    fp.close();
}

void employee::showInfo()
{

}

void employee::getInfo()
{
    cout<<"\t\t\tJob Title: "<<title<<endl;
    cout<<"\t\t\tName: "<<name<<endl;
    cout<<"\t\t\tAge: "<<age<<endl;
    cout<<"\t\t\tPhone number: "<<phone<<endl;
    cout<<"\t\t\tEmployee ID: "<<ID<<endl;
    cout<<"\t\t\tShift: "<<shift<<endl;
    cout<<"\t\t\tSalary: "<<salary<<endl;
}

void employee::getSal()
{
    cout<<"\t\t\tSalary: "<<salary<<endl;
}
void employee::getShift()
{
    cout<<"\t\t\tShift: "<<shift<<endl;
}
