#include "person.h"

#include <iostream>

using namespace std;

person:: person()
{
    name="";
    phone=-1;
    age=-1;
}

person::person(string n, long long int p, int a)
{
    name=n;
    phone=p;
    age=a;
}

person:: ~person()
{

}


