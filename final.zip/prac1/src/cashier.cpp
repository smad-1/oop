#include "cashier.h"

cashier::cashier(string user, string pass,int i):employee(user,pass,i)
{
    //ctor
}

cashier::cashier(string user, string pass, string n, int a, long long int p, int i, string shif,int sal):employee(user,pass,i)
{
    name=n;
    age=a;
    phone=p;
    shift=shif;
    salary=sal;
    title="Cashier";
}

cashier::~cashier()
{
    //dtor
}

void cashier::showUser()
{
    getInfo();
}

void cashier::showInfo()
{
    cout<<"\t\t\tJob Title: "<<title<<endl;
    cout<<"\t\t\tName: "<<name<<endl;
    cout<<"\t\t\tAge: "<<age<<endl;
    cout<<"\t\t\tPhone number: "<<phone<<endl;
    cout<<"\t\t\tEmployee ID: "<<ID<<endl;
  //  cout<<"\t\t\tShift: "<<shift<<endl;
  //  cout<<"\t\t\tSalary: "<<salary<<endl;
}
