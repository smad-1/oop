#ifndef MYGLOBALS_H_INCLUDED
#define MYGLOBALS_H_INCLUDED

#include <unordered_map>
#include "employee.h"
#include "course.h"

#pragma once

namespace globals{

  extern employee* emps[100];
  extern int emp_count;
  extern unordered_map <int,bool> checkID;
  extern int maxID;

  extern course* items[100];
  extern int courseNum;
  extern int startNum;
  extern int mainNum;
  extern int desNum;
  extern int drinkNum;

}

#endif // MYGLOBALS_H_INCLUDED
