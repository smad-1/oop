#include <bits/stdc++.h>
#ifndef MAINCOURSE_H
#define MAINCOURSE_H

#include "course.h"

using namespace std;

class main_course : public course
{
    public:
        main_course(int num, string n, float p):course(num,n,p)
        {

        }
        void showCourse()
        {
            cout<<num<<".    "<<n<<"    TK "<<p<<endl;
        }

};

#endif
