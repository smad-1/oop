#include <bits/stdc++.h>
#ifndef DESSERT_H
#define DESSERT_H

#include "course.h"

using namespace std;

class dessert : public course
{
public:
    dessert(int num, string n, float p):course(num,n,p)
    {

    }

    void showCourse()
    {
        cout<<num<<".    "<<n<<"    TK "<<p<<endl;
    }

};

#endif
