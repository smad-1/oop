#include <bits/stdc++.h>
#ifndef STARTER_H
#define STARTER_H

#include "course.h"


using namespace std;

class starter:public course
{
    public:
        starter(int num, string n, float p): course(num,n,p)
        {

        }

        void showCourse()
        {
            cout<<num<<".    "<<n<<"    TK "<<p<<endl;
        }


};

#endif
