#include <bits/stdc++.h>
#ifndef DRINKS_H
#define DRINKS_H

#include "course.h"

using namespace std;

class drinks : public course
{
    public:
       drinks(int num, string n, float p): course(num,n,p)
       {

       }

       void showCourse()
       {
           cout<<num<<".    "<<n<<"    TK "<<p<<endl;
       }

};

#endif
